"""Generates assets/hero.png (illustration) and docs/little-lemon-wireframe.jpg (wireframe)."""
from PIL import Image, ImageDraw, ImageFont

def font(size, bold=False):
    name = "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"
    try: return ImageFont.truetype(name, size)
    except OSError: return ImageFont.load_default()

# ---- Hero illustration: lemons on a yellow tile ----
img = Image.new("RGB", (400, 400), "#F4CE14"); d = ImageDraw.Draw(img)
d.ellipse([60, 120, 340, 320], fill="#FFE55C", outline="#C9A800", width=6)
d.ellipse([320, 190, 360, 250], fill="#FFE55C", outline="#C9A800", width=6)
d.ellipse([40, 190, 80, 250], fill="#FFE55C", outline="#C9A800", width=6)
d.ellipse([170, 60, 300, 130], fill="#495E57")   # leaf
d.line([200, 130, 215, 105], fill="#2f3f3a", width=6)
d.ellipse([120, 160, 180, 200], fill="#FFF3A0")  # shine
img.save("assets/hero.png")

# ---- Wireframe of the Home screen ----
W, H = 700, 1300
wf = Image.new("RGB", (W, H), "white"); d = ImageDraw.Draw(wf)
f, fb, fs = font(24), font(26, True), font(20)
def box(xy, label, fill="white", w=3):
    d.rectangle(xy, fill=fill, outline="black", width=w)
    d.text(((xy[0]+xy[2])/2, (xy[1]+xy[3])/2), label, fill="black", font=f, anchor="mm")
d.text((W/2, 40), "Little Lemon - Home Screen Wireframe", fill="black", font=fb, anchor="mm")
box((120, 80, 580, 1230), "", w=5)                       # phone
box((140, 100, 560, 170), ""); d.text((350, 135), "HEADER", font=fb, fill="black", anchor="mm")
d.text((200, 135), "[Logo]", font=fs, fill="black", anchor="mm"); d.ellipse([500, 108, 546, 154], outline="black", width=3)
box((140, 180, 560, 450), "", fill="#DDDDDD")
d.text((350, 205), "HERO SECTION", font=fb, fill="black", anchor="mm")
d.text((160, 250), "Little Lemon", font=fb, fill="black"); d.text((160, 285), "Chicago", font=f, fill="black")
for i in range(3): d.line([160, 330+i*22, 340, 330+i*22], fill="black", width=3)
box((370, 240, 540, 380), "Hero\nImage")
box((160, 395, 540, 435), "SEARCH BAR", fill="white")
d.text((350, 480), "MENU BREAKDOWN", font=fb, fill="black", anchor="mm")
for i, name in enumerate(["Starters", "Mains", "Desserts", "Drinks"]):
    x = 150 + i*100; d.rounded_rectangle([x, 505, x+92, 545], radius=18, outline="black", width=3)
    d.text((x+46, 525), name, font=font(15), fill="black", anchor="mm")
d.text((350, 590), "FOOD MENU LIST", font=fb, fill="black", anchor="mm")
for i in range(4):
    y = 620 + i*150
    d.rectangle([140, y, 560, y+135], outline="black", width=3)
    d.text((160, y+15), "Dish name", font=fs, fill="black"); d.text((160, y+90), "$ Price", font=fs, fill="black")
    for k in range(2): d.line([160, y+55+k*18, 380, y+55+k*18], fill="black", width=3)
    d.rectangle([420, y+20, 540, y+115], outline="black", width=3); d.text((480, y+67), "Image", font=font(18), fill="black", anchor="mm")
wf.save("docs/little-lemon-wireframe.jpg", quality=92)
