# Little Lemon Food Ordering App

React Native (Expo) app for the Meta React Native Capstone. It has Onboarding, Home (menu with search and category filters) and Profile screens.

## Features
- **Onboarding**: first name and email, with validation. Next stays disabled until both are valid. Details are saved, so the app skips onboarding on later launches.
- **Home**: header with avatar, hero section, search bar, Starters/Mains/Desserts/Drinks buttons and an 8-item menu. Search and category filters work together. Tap the selected category again to show all. An empty state shows when nothing matches.
- **Profile**: edit first name, last name, email and phone (validated), toggle 4 email notification preferences, Save, Discard (restores last saved values), Log out (clears storage and returns to Onboarding), Back button.
- **Storage**: AsyncStorage keeps the onboarding flag, profile and notification preferences. No passwords are stored.
- **Navigation**: React Navigation native stack.

## Run it
```bash
npm install
npx expo start
```
Scan the QR code with the Expo Go app, or press `a` (Android emulator) or `i` (iOS simulator).

## Structure
```
App.js                  navigation + startup loading
src/constants.js        colors, menu data, default profile
src/screens/            OnboardingScreen, HomeScreen, ProfileScreen
src/components/         Header, Avatar, MenuItem, CategoryButtons
src/utils/              storage.js (AsyncStorage), validation.js
assets/hero.png         generated hero illustration
docs/little-lemon-wireframe.jpg   Home screen wireframe
```

## Notes
Food images are emoji placeholders and the hero is a generated illustration. Replace them with real photos in `src/constants.js` and `assets/` if you like.
