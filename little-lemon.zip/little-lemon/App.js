import React, { useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import OnboardingScreen from './src/screens/OnboardingScreen';
import HomeScreen from './src/screens/HomeScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import { ProfileContext } from './src/ProfileContext';
import { loadProfile, saveProfile, clearProfile } from './src/utils/storage';
import { EMPTY_PROFILE, COLORS } from './src/constants';

const Stack = createNativeStackNavigator();

export default function App() {
  const [profile, setProfile] = useState(EMPTY_PROFILE);
  const [isLoading, setIsLoading] = useState(true);

  // On startup, read the saved profile from AsyncStorage
  useEffect(() => {
    loadProfile()
      .then(setProfile)
      .catch((error) => console.log('Could not load profile', error))
      .finally(() => setIsLoading(false));
  }, []);

  // Save the profile to storage and to state
  const updateProfile = async (newProfile) => {
    await saveProfile(newProfile);
    setProfile(newProfile);
  };

  // Log out: clear storage, reset state (this switches the navigator back to Onboarding)
  const logout = async () => {
    await clearProfile();
    setProfile(EMPTY_PROFILE);
  };

  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: COLORS.white }}>
        <ActivityIndicator size="large" color={COLORS.green} />
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <ProfileContext.Provider value={{ profile, updateProfile, logout }}>
        <NavigationContainer>
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            {/* Only one set of screens exists at a time, so there are no navigation loops */}
            {profile.onboardingCompleted ? (
              <>
                <Stack.Screen name="Home" component={HomeScreen} />
                <Stack.Screen name="Profile" component={ProfileScreen} />
              </>
            ) : (
              <Stack.Screen name="Onboarding" component={OnboardingScreen} />
            )}
          </Stack.Navigator>
        </NavigationContainer>
      </ProfileContext.Provider>
      <StatusBar style="dark" />
    </SafeAreaProvider>
  );
}
