import React, { useContext, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image, ScrollView, KeyboardAvoidingView, Platform, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Header from '../components/Header';
import { ProfileContext } from '../ProfileContext';
import { isValidName, isValidEmail } from '../utils/validation';
import { COLORS } from '../constants';

export default function OnboardingScreen() {
  const { profile, updateProfile } = useContext(ProfileContext);
  const [firstName, setFirstName] = useState('');
  const [email, setEmail] = useState('');

  // The Next button is only enabled when both fields are valid
  const nameOk = isValidName(firstName);
  const emailOk = isValidEmail(email);
  const canContinue = nameOk && emailOk;

  const handleNext = async () => {
    // Saving onboardingCompleted = true makes App.js show the Home screen
    await updateProfile({ ...profile, onboardingCompleted: true, firstName: firstName.trim(), email: email.trim() });
  };

  return (
    <SafeAreaView style={styles.container}>
      <Header />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.scroll}>
          <View style={styles.hero}>
            <Text style={styles.title}>Little Lemon</Text>
            <Text style={styles.subtitle}>Chicago</Text>
            <View style={styles.heroRow}>
              <Text style={styles.description}>
                A family owned Mediterranean restaurant, focused on traditional recipes served with a modern twist.
              </Text>
              <Image source={require('../../assets/hero.png')} style={styles.heroImage} />
            </View>
          </View>

          <View style={styles.form}>
            <Text style={styles.heading}>Let us get to know you</Text>

            <Text style={styles.label}>First Name</Text>
            <TextInput style={styles.input} value={firstName} onChangeText={setFirstName} placeholder="Your first name" autoCapitalize="words" />
            {firstName.length > 0 && !nameOk && <Text style={styles.error}>Name can only contain letters.</Text>}

            <Text style={styles.label}>Email</Text>
            <TextInput style={styles.input} value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address" autoCapitalize="none" autoCorrect={false} />
            {email.length > 0 && !emailOk && <Text style={styles.error}>Please enter a valid email address.</Text>}

            <TouchableOpacity style={[styles.button, !canContinue && styles.buttonDisabled]} onPress={handleNext} disabled={!canContinue}>
              <Text style={styles.buttonText}>Next</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.white },
  scroll: { flexGrow: 1 },
  hero: { backgroundColor: COLORS.green, padding: 20 },
  title: { fontSize: 40, fontWeight: 'bold', color: COLORS.yellow },
  subtitle: { fontSize: 24, color: COLORS.white, marginBottom: 10 },
  heroRow: { flexDirection: 'row', alignItems: 'center' },
  description: { flex: 1, fontSize: 16, color: COLORS.white, paddingRight: 12 },
  heroImage: { width: 110, height: 110, borderRadius: 16 },
  form: { padding: 24, backgroundColor: COLORS.gray, flexGrow: 1 },
  heading: { fontSize: 24, fontWeight: 'bold', color: COLORS.green, textAlign: 'center', marginBottom: 20 },
  label: { fontSize: 16, fontWeight: 'bold', color: COLORS.green, marginBottom: 6, marginTop: 10 },
  input: { backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.green, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10, fontSize: 16 },
  error: { color: '#B00020', marginTop: 4 },
  button: { backgroundColor: COLORS.yellow, borderRadius: 8, paddingVertical: 14, alignItems: 'center', marginTop: 30 },
  buttonDisabled: { opacity: 0.4 },
  buttonText: { fontSize: 18, fontWeight: 'bold', color: COLORS.text },
});
