import React, { useContext, useState } from 'react';
import { View, Text, TextInput, FlatList, Image, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Header from '../components/Header';
import MenuItem from '../components/MenuItem';
import CategoryButtons from '../components/CategoryButtons';
import { ProfileContext } from '../ProfileContext';
import { MENU_ITEMS, COLORS } from '../constants';

export default function HomeScreen({ navigation }) {
  const { profile } = useContext(ProfileContext);
  const [searchText, setSearchText] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(null); // null = show all

  // Search and category filters work together: an item must match BOTH
  const visibleItems = MENU_ITEMS.filter((item) => {
    const matchesCategory = selectedCategory === null || item.category === selectedCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchText.trim().toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Everything above the food list (hero, search, categories) scrolls with the list
  const listHeader = (
    <View>
      <View style={styles.hero}>
        <Text style={styles.title}>Little Lemon</Text>
        <Text style={styles.location}>Chicago</Text>
        <View style={styles.heroRow}>
          <Text style={styles.description}>
            We are a family owned Mediterranean restaurant, focused on traditional recipes served with a modern twist.
          </Text>
          <Image source={require('../../assets/hero.png')} style={styles.heroImage} />
        </View>
        <TextInput style={styles.search} value={searchText} onChangeText={setSearchText} placeholder="🔍  Search menu" placeholderTextColor="#777" clearButtonMode="while-editing" />
      </View>
      <Text style={styles.sectionTitle}>ORDER FOR DELIVERY!</Text>
      <CategoryButtons selected={selectedCategory} onSelect={setSelectedCategory} />
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <Header profile={profile} onProfilePress={() => navigation.navigate('Profile')} />
      <FlatList
        data={visibleItems}
        keyExtractor={(item) => String(item.id)}
        renderItem={({ item }) => <MenuItem item={item} />}
        ListHeaderComponent={listHeader}
        ListEmptyComponent={<Text style={styles.empty}>No menu items match your search.</Text>}
        keyboardShouldPersistTaps="handled"
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.white },
  hero: { backgroundColor: COLORS.green, padding: 16 },
  title: { fontSize: 40, fontWeight: 'bold', color: COLORS.yellow },
  location: { fontSize: 24, color: COLORS.white, marginBottom: 8 },
  heroRow: { flexDirection: 'row', alignItems: 'center' },
  description: { flex: 1, fontSize: 16, color: COLORS.white, paddingRight: 12 },
  heroImage: { width: 110, height: 120, borderRadius: 16 },
  search: { backgroundColor: COLORS.gray, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 10, fontSize: 16, marginTop: 16 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', color: COLORS.text, paddingHorizontal: 16, paddingTop: 16 },
  empty: { textAlign: 'center', color: COLORS.green, fontSize: 16, padding: 30 },
});
