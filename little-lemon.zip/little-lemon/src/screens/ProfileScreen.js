import React, { useContext, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Switch, ScrollView, Alert, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Header from '../components/Header';
import Avatar from '../components/Avatar';
import { ProfileContext } from '../ProfileContext';
import { isValidName, isValidEmail, isValidPhone } from '../utils/validation';
import { COLORS } from '../constants';

const NOTIFICATION_OPTIONS = [
  { key: 'orderStatuses', label: 'Order statuses' },
  { key: 'passwordChanges', label: 'Password changes' },
  { key: 'specialOffers', label: 'Special offers' },
  { key: 'newsletter', label: 'Newsletter' },
];

export default function ProfileScreen({ navigation }) {
  const { profile, updateProfile, logout } = useContext(ProfileContext);
  // "form" holds unsaved edits; "profile" is the last saved version
  const [form, setForm] = useState(profile);

  const setField = (field, value) => setForm({ ...form, [field]: value });
  const setNotification = (key, value) => setForm({ ...form, notifications: { ...form.notifications, [key]: value } });

  const handleSave = async () => {
    if (!isValidName(form.firstName)) return Alert.alert('Invalid first name', 'Use letters only.');
    if (form.lastName.trim() !== '' && !isValidName(form.lastName)) return Alert.alert('Invalid last name', 'Use letters only.');
    if (!isValidEmail(form.email)) return Alert.alert('Invalid email', 'Please enter a valid email address.');
    if (!isValidPhone(form.phone)) return Alert.alert('Invalid phone', 'Enter 10 digits, numbers only.');
    await updateProfile(form);
    Alert.alert('Saved', 'Your changes have been saved.');
  };

  // Discard: put the last saved values back into the form
  const handleDiscard = () => setForm(profile);

  const field = (label, name, extra = {}) => (
    <>
      <Text style={styles.label}>{label}</Text>
      <TextInput style={styles.input} value={form[name]} onChangeText={(text) => setField(name, text)} {...extra} />
    </>
  );

  return (
    <SafeAreaView style={styles.container}>
      <Header onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        <Text style={styles.heading}>Personal information</Text>
        <View style={styles.avatarRow}>
          <Avatar profile={form} size={80} />
        </View>

        {field('First name', 'firstName', { autoCapitalize: 'words' })}
        {field('Last name', 'lastName', { autoCapitalize: 'words' })}
        {field('Email', 'email', { keyboardType: 'email-address', autoCapitalize: 'none', autoCorrect: false })}
        {field('Phone number', 'phone', { keyboardType: 'phone-pad', maxLength: 10, placeholder: '10 digits' })}

        <Text style={[styles.heading, { marginTop: 24 }]}>Email notifications</Text>
        {NOTIFICATION_OPTIONS.map((option) => (
          <View key={option.key} style={styles.switchRow}>
            <Text style={styles.switchLabel}>{option.label}</Text>
            <Switch value={form.notifications[option.key]} onValueChange={(value) => setNotification(option.key, value)} trackColor={{ true: COLORS.green }} thumbColor={COLORS.yellow} />
          </View>
        ))}

        <TouchableOpacity style={styles.logoutButton} onPress={logout}>
          <Text style={styles.logoutText}>Log out</Text>
        </TouchableOpacity>

        <View style={styles.buttonRow}>
          <TouchableOpacity style={[styles.smallButton, styles.discardButton]} onPress={handleDiscard}>
            <Text style={styles.discardText}>Discard changes</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.smallButton, styles.saveButton]} onPress={handleSave}>
            <Text style={styles.saveText}>Save changes</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.white },
  scroll: { padding: 20, paddingBottom: 40 },
  heading: { fontSize: 20, fontWeight: 'bold', color: COLORS.text, marginBottom: 12 },
  avatarRow: { alignItems: 'center', marginBottom: 10 },
  label: { fontSize: 14, fontWeight: 'bold', color: COLORS.green, marginTop: 10, marginBottom: 4 },
  input: { borderWidth: 1, borderColor: COLORS.green, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10, fontSize: 16 },
  switchRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 6 },
  switchLabel: { fontSize: 16, color: COLORS.text },
  logoutButton: { backgroundColor: COLORS.yellow, borderRadius: 8, paddingVertical: 14, alignItems: 'center', marginTop: 28 },
  logoutText: { fontSize: 18, fontWeight: 'bold', color: COLORS.text },
  buttonRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 20 },
  smallButton: { flex: 1, borderRadius: 8, paddingVertical: 12, alignItems: 'center', borderWidth: 1, borderColor: COLORS.green },
  discardButton: { backgroundColor: COLORS.white, marginRight: 8 },
  saveButton: { backgroundColor: COLORS.green, marginLeft: 8 },
  discardText: { fontSize: 16, fontWeight: 'bold', color: COLORS.green },
  saveText: { fontSize: 16, fontWeight: 'bold', color: COLORS.white },
});
