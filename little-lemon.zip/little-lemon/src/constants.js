// Colors from the Little Lemon style guide
export const COLORS = {
  green: '#495E57',
  yellow: '#F4CE14',
  white: '#FFFFFF',
  gray: '#EDEFEE',
  text: '#333333',
};

export const CATEGORIES = ['Starters', 'Mains', 'Desserts', 'Drinks'];

// Menu data. "emoji" is a simple placeholder in place of a food photo.
export const MENU_ITEMS = [
  { id: 1, name: 'Greek Salad', category: 'Starters', price: 12.99, emoji: '🥗', description: 'Crisp lettuce, peppers, olives and feta cheese with olive oil.' },
  { id: 2, name: 'Bruschetta', category: 'Starters', price: 7.99, emoji: '🍅', description: 'Grilled bread rubbed with garlic, topped with tomato and basil.' },
  { id: 3, name: 'Grilled Fish', category: 'Mains', price: 20.0, emoji: '🐟', description: 'Fresh fish grilled with lemon, herbs and roasted vegetables.' },
  { id: 4, name: 'Pasta', category: 'Mains', price: 18.99, emoji: '🍝', description: 'Homemade pasta in a creamy tomato and parmesan sauce.' },
  { id: 5, name: 'Lemon Dessert', category: 'Desserts', price: 6.99, emoji: '🍰', description: 'Traditional lemon cake with a sweet, tangy glaze.' },
  { id: 6, name: 'Tiramisu', category: 'Desserts', price: 7.5, emoji: '🍮', description: 'Coffee-soaked sponge layered with mascarpone cream.' },
  { id: 7, name: 'Lemon Drink', category: 'Drinks', price: 4.5, emoji: '🍋', description: 'Fresh squeezed lemonade served over ice with mint.' },
  { id: 8, name: 'Iced Tea', category: 'Drinks', price: 3.99, emoji: '🧋', description: 'Chilled black tea with a slice of lemon.' },
];

// Default profile saved on first run
export const EMPTY_PROFILE = {
  onboardingCompleted: false,
  firstName: '',
  lastName: '',
  email: '',
  phone: '',
  notifications: {
    orderStatuses: true,
    passwordChanges: true,
    specialOffers: true,
    newsletter: true,
  },
};
