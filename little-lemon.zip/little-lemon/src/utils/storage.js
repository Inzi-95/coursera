import AsyncStorage from '@react-native-async-storage/async-storage';
import { EMPTY_PROFILE } from '../constants';

const PROFILE_KEY = 'littleLemonProfile';

// Read the saved profile (or the empty default if nothing is saved yet)
export async function loadProfile() {
  const json = await AsyncStorage.getItem(PROFILE_KEY);
  if (!json) return EMPTY_PROFILE;
  const saved = JSON.parse(json);
  // merge so older saves still have every field
  return { ...EMPTY_PROFILE, ...saved, notifications: { ...EMPTY_PROFILE.notifications, ...saved.notifications } };
}

export async function saveProfile(profile) {
  await AsyncStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
}

// Used by Log out: removes everything stored
export async function clearProfile() {
  await AsyncStorage.removeItem(PROFILE_KEY);
}
