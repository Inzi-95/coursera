// Name must contain letters only (spaces allowed inside)
export const isValidName = (name) => /^[A-Za-z]+(?: [A-Za-z]+)*$/.test(name.trim());

// Simple email format check: something@something.something
export const isValidEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());

// Phone is optional. If given, it must be 10 digits (US format)
export const isValidPhone = (phone) => phone.trim() === '' || /^\d{10}$/.test(phone.trim());
