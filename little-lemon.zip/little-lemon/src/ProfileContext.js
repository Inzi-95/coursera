import { createContext } from 'react';

// Shares the profile and helper functions with every screen
export const ProfileContext = createContext(null);
