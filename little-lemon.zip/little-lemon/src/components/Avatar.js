import React from 'react';
import { View, Text } from 'react-native';
import { COLORS } from '../constants';

// Round avatar showing the user's initials (a placeholder instead of a photo)
export default function Avatar({ profile, size = 40 }) {
  const initials = ((profile.firstName[0] || '') + (profile.lastName[0] || '')).toUpperCase() || '?';
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: COLORS.yellow, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ fontSize: size * 0.4, fontWeight: 'bold', color: COLORS.green }}>{initials}</Text>
    </View>
  );
}
