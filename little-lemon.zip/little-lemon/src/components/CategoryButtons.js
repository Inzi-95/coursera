import React from 'react';
import { ScrollView, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { COLORS, CATEGORIES } from '../constants';

// Rounded filter buttons. Tapping the selected one again clears the filter (shows all).
export default function CategoryButtons({ selected, onSelect }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row}>
      {CATEGORIES.map((category) => {
        const isSelected = category === selected;
        return (
          <TouchableOpacity
            key={category}
            style={[styles.button, isSelected && styles.buttonSelected]}
            onPress={() => onSelect(isSelected ? null : category)}
          >
            <Text style={[styles.label, isSelected && styles.labelSelected]}>{category}</Text>
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  row: { paddingHorizontal: 16, paddingVertical: 12 },
  button: { backgroundColor: COLORS.gray, borderRadius: 20, paddingHorizontal: 18, paddingVertical: 8, marginRight: 10 },
  buttonSelected: { backgroundColor: COLORS.green },
  label: { fontSize: 15, fontWeight: 'bold', color: COLORS.green },
  labelSelected: { color: COLORS.white },
});
