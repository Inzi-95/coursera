import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import Avatar from './Avatar';
import { COLORS } from '../constants';

// Top bar. Optional back button (left) and optional avatar (right).
export default function Header({ onBack, profile, onProfilePress }) {
  return (
    <View style={styles.header}>
      <View style={styles.side}>
        {onBack && (
          <TouchableOpacity style={styles.backButton} onPress={onBack} accessibilityLabel="Go back">
            <Text style={styles.backArrow}>←</Text>
          </TouchableOpacity>
        )}
      </View>
      <Text style={styles.logo}>Little <Text style={styles.logoAccent}>Lemon</Text> 🍋</Text>
      <View style={[styles.side, { alignItems: 'flex-end' }]}>
        {profile && (
          <TouchableOpacity onPress={onProfilePress} accessibilityLabel="Open profile">
            <Avatar profile={profile} size={42} />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 10, backgroundColor: COLORS.white },
  side: { width: 50 },
  logo: { fontSize: 22, fontWeight: 'bold', color: COLORS.green },
  logoAccent: { color: '#C9A800' },
  backButton: { width: 40, height: 40, borderRadius: 20, backgroundColor: COLORS.green, alignItems: 'center', justifyContent: 'center' },
  backArrow: { color: COLORS.white, fontSize: 20, fontWeight: 'bold' },
});
