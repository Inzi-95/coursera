import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { COLORS } from '../constants';

// One row in the food menu list
export default function MenuItem({ item }) {
  return (
    <View style={styles.card}>
      <View style={styles.textBox}>
        <Text style={styles.name}>{item.name}</Text>
        <Text style={styles.description} numberOfLines={2}>{item.description}</Text>
        <Text style={styles.price}>${item.price.toFixed(2)}</Text>
      </View>
      <View style={styles.imageBox}>
        <Text style={styles.emoji}>{item.emoji}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { flexDirection: 'row', paddingVertical: 14, paddingHorizontal: 16, borderBottomWidth: 1, borderBottomColor: COLORS.gray, backgroundColor: COLORS.white },
  textBox: { flex: 1, paddingRight: 12 },
  name: { fontSize: 18, fontWeight: 'bold', color: COLORS.text, marginBottom: 4 },
  description: { fontSize: 14, color: COLORS.green, marginBottom: 6 },
  price: { fontSize: 16, fontWeight: '600', color: COLORS.text },
  imageBox: { width: 80, height: 80, borderRadius: 10, backgroundColor: COLORS.gray, alignItems: 'center', justifyContent: 'center' },
  emoji: { fontSize: 40 },
});
